package vista;

import modelo.Seguridad;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class VentanaPrincipal extends JFrame {

    private JTextField[][] campos = new JTextField[3][4];
    private JTextArea areaResultados;
    private JTable tablaMatriz;
    private DefaultTableModel modeloTabla;
    private JTabbedPane tabs;

    // Etiquetas de resultado visibles en la pestaña tabla
    private JLabel lblDet, lblX, lblY, lblZ, lblPunto, lblHomo;

    public VentanaPrincipal() {
        setTitle("Recuperacion de Llaves Criptograficas - Algebra Lineal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(960, 700);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(new EmptyBorder(14, 14, 14, 14));
        root.setBackground(new Color(240, 243, 250));
        setContentPane(root);

        // HEADER
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(18, 83, 150));
        header.setBorder(new EmptyBorder(12, 18, 12, 18));
        JLabel titulo = new JLabel("  Recuperacion de Llaves Criptograficas");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 17));
        titulo.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Algebra Lineal  |  Colegio Mayor del Cauca");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        sub.setForeground(new Color(170, 200, 240));
        JPanel ht = new JPanel(new GridLayout(2, 1, 0, 2));
        ht.setOpaque(false);
        ht.add(titulo); ht.add(sub);
        header.add(ht, BorderLayout.CENTER);
        root.add(header, BorderLayout.NORTH);

        // SPLIT
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setDividerLocation(365);
        split.setDividerSize(5);
        split.setBorder(null);
        split.setBackground(new Color(240, 243, 250));
        root.add(split, BorderLayout.CENTER);

        // ===== IZQUIERDA: entrada =====
        JPanel izq = new JPanel(new BorderLayout(0, 10));
        izq.setOpaque(false);
        izq.setBorder(new EmptyBorder(8, 0, 0, 6));
        split.setLeftComponent(izq);

        izq.add(secLabel("Ingreso de paquetes"), BorderLayout.NORTH);

        JPanel packs = new JPanel(new GridLayout(3, 1, 0, 8));
        packs.setOpaque(false);
        String[] cols = {"Llave A", "Llave B", "Llave C", "Resultado"};
        for (int i = 0; i < 3; i++) {
            JPanel card = card("Paquete " + (i + 1));
            JPanel g = new JPanel(new GridLayout(2, 4, 8, 4));
            g.setOpaque(false);
            for (String c : cols) {
                JLabel l = new JLabel(c, SwingConstants.CENTER);
                l.setFont(new Font("Segoe UI", Font.PLAIN, 11));
                l.setForeground(new Color(100, 110, 130));
                g.add(l);
            }
            for (int j = 0; j < 4; j++) {
                campos[i][j] = new JTextField("0");
                campos[i][j].setHorizontalAlignment(JTextField.CENTER);
                campos[i][j].setFont(new Font("Consolas", Font.PLAIN, 14));
                campos[i][j].setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(190, 205, 225), 1, true),
                    new EmptyBorder(4, 4, 4, 4)));
                g.add(campos[i][j]);
            }
            card.add(g, BorderLayout.CENTER);
            packs.add(card);
        }
        izq.add(packs, BorderLayout.CENTER);

        JPanel btns = new JPanel(new GridLayout(1, 2, 8, 0));
        btns.setOpaque(false);
        JButton calc = boton("Calcular llaves", new Color(18, 83, 150), Color.BLUE);
        calc.addActionListener(e -> calcular());
        JButton reset = boton("Limpiar", new Color(220, 228, 240), new Color(40, 70, 120));
        reset.addActionListener(e -> limpiar());
        btns.add(calc); btns.add(reset);
        izq.add(btns, BorderLayout.SOUTH);

        // ===== DERECHA: resultados =====
        JPanel der = new JPanel(new BorderLayout(0, 8));
        der.setOpaque(false);
        der.setBorder(new EmptyBorder(8, 6, 0, 0));
        split.setRightComponent(der);

        der.add(secLabel("Resultados"), BorderLayout.NORTH);

        tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        // ---- TAB 1: Resumen visual ----
        JPanel tabResumen = new JPanel(new BorderLayout(0, 10));
        tabResumen.setBackground(new Color(248, 250, 255));
        tabResumen.setBorder(new EmptyBorder(12, 12, 12, 12));

        // Tabla matriz aumentada
        String[] colsT = {"Paquete", "A", "B", "C", "| b"};
        modeloTabla = new DefaultTableModel(colsT, 3) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tablaMatriz = new JTable(modeloTabla);
        tablaMatriz.setFont(new Font("Consolas", Font.PLAIN, 13));
        tablaMatriz.setRowHeight(28);
        tablaMatriz.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tablaMatriz.getTableHeader().setBackground(new Color(220, 232, 248));
        tablaMatriz.setGridColor(new Color(205, 218, 235));
        tablaMatriz.setSelectionBackground(new Color(185, 212, 245));
        tablaMatriz.getColumnModel().getColumn(0).setPreferredWidth(75);
        tablaMatriz.getColumnModel().getColumn(4).setPreferredWidth(65);
        JScrollPane st = new JScrollPane(tablaMatriz);
        st.setBorder(new LineBorder(new Color(195, 212, 235), 1));
        st.setPreferredSize(new Dimension(0, 120));

        JPanel matCard = new JPanel(new BorderLayout(0, 6));
        matCard.setOpaque(false);
        matCard.add(secLabel("Matriz aumentada [A|b]"), BorderLayout.NORTH);
        matCard.add(st, BorderLayout.CENTER);

        // Panel de resultados clave
        JPanel resPanel = new JPanel(new GridLayout(0, 1, 0, 6));
        resPanel.setOpaque(false);

        lblDet   = resultRow("Determinante det(A)", "---");
        lblX     = resultRow("Llave  x =", "---");
        lblY     = resultRow("Llave  y =", "---");
        lblZ     = resultRow("Llave  z =", "---");
        lblPunto = resultRow("Producto punto  K \u00b7 W =", "---");
        lblHomo  = resultRow("Homogeneidad  10\u00d7(K\u00b7W) =", "---");

        resPanel.add(filaResultado("Determinante  det(A)", lblDet, new Color(230, 240, 255)));
        resPanel.add(filaResultado("Llave  x", lblX, new Color(232, 248, 235)));
        resPanel.add(filaResultado("Llave  y", lblY, new Color(232, 248, 235)));
        resPanel.add(filaResultado("Llave  z", lblZ, new Color(232, 248, 235)));
        resPanel.add(filaResultado("Producto punto  K \b7 W", lblPunto, new Color(255, 248, 225)));
        resPanel.add(filaResultado("Homogeneidad  c\u00d7(K\b7W)", lblHomo, new Color(255, 248, 225)));

        JPanel resPanelWrap = new JPanel(new BorderLayout(0, 6));
        resPanelWrap.setOpaque(false);
        resPanelWrap.add(secLabel("Valores calculados"), BorderLayout.NORTH);
        resPanelWrap.add(resPanel, BorderLayout.CENTER);

        tabResumen.add(matCard, BorderLayout.NORTH);
        tabResumen.add(resPanelWrap, BorderLayout.CENTER);

        tabs.addTab("Resumen", tabResumen);

        // ---- TAB 2: JTextArea detalle completo ----
        areaResultados = new JTextArea();
        areaResultados.setFont(new Font("Consolas", Font.PLAIN, 13));
        areaResultados.setEditable(false);
        areaResultados.setBackground(new Color(252, 253, 255));
        areaResultados.setForeground(new Color(25, 35, 55));
        areaResultados.setMargin(new Insets(12, 14, 12, 14));
        areaResultados.setText("Ingresa los coeficientes y presiona\n\"Calcular llaves\" para ver el detalle completo.");
        JScrollPane sa = new JScrollPane(areaResultados);
        sa.setBorder(new LineBorder(new Color(195, 212, 235), 1));
        tabs.addTab("Detalle completo", sa);

        der.add(tabs, BorderLayout.CENTER);
    }

    // ===== LOGICA =====
    private void calcular() {
        double[][] A = new double[3][3];
        double[] b = new double[3];
        try {
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) A[i][j] = Double.parseDouble(campos[i][j].getText().trim());
                b[i] = Double.parseDouble(campos[i][3].getText().trim());
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Solo ingresa valores numericos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Llenar JTable
        for (int i = 0; i < 3; i++) {
            modeloTabla.setValueAt("Paquete " + (i + 1), i, 0);
            for (int j = 0; j < 3; j++) modeloTabla.setValueAt(String.format("%.2f", A[i][j]), i, j + 1);
            modeloTabla.setValueAt(String.format("%.2f", b[i]), i, 4);
        }

        double det = Seguridad.determinante(A);

        // Actualizar etiquetas del resumen
        lblDet.setText(String.format("%.4f", det));

        StringBuilder sb = new StringBuilder();
        sb.append("============================================\n");
        sb.append("  RECUPERACION DE LLAVES CRIPTOGRAFICAS\n");
        sb.append("  Algebra Lineal - Colegio Mayor del Cauca\n");
        sb.append("============================================\n\n");

        sb.append("--- Matriz Aumentada [A|b] -----------------\n");
        sb.append(String.format("  %-10s %-10s %-10s | %-8s%n", "A", "B", "C", "b"));
        for (int i = 0; i < 3; i++)
            sb.append(String.format("  %-10.2f %-10.2f %-10.2f | %.2f%n", A[i][0], A[i][1], A[i][2], b[i]));

        sb.append("\n--- Determinante (Regla de Sarrus) ---------\n");
        double p1=A[0][0]*A[1][1]*A[2][2], p2=A[0][1]*A[1][2]*A[2][0], p3=A[0][2]*A[1][0]*A[2][1];
        double n1=A[2][0]*A[1][1]*A[0][2], n2=A[2][1]*A[1][2]*A[0][0], n3=A[2][2]*A[1][0]*A[0][1];
        sb.append(String.format("  Diagonales (+): %.2f + %.2f + %.2f = %.2f%n", p1, p2, p3, p1+p2+p3));
        sb.append(String.format("  Diagonales (-): %.2f + %.2f + %.2f = %.2f%n", n1, n2, n3, n1+n2+n3));
        sb.append(String.format("  det(A) = %.4f%n", det));

        if (Math.abs(det) < 1e-10) {
            sb.append("  ADVERTENCIA: det = 0, no hay solucion unica.\n");
            lblX.setText("sin solucion"); lblY.setText("sin solucion"); lblZ.setText("sin solucion");
            lblPunto.setText("---"); lblHomo.setText("---");
            areaResultados.setText(sb.toString());
            tabs.setSelectedIndex(1);
            return;
        }
        sb.append("  det != 0 -> El sistema tiene solucion unica.\n");

        double[] llaves = Seguridad.gaussJordan(A, b);
        sb.append("\n--- Solucion por Gauss-Jordan --------------\n");
        sb.append(String.format("  x = %.4f%n", llaves[0]));
        sb.append(String.format("  y = %.4f%n", llaves[1]));
        sb.append(String.format("  z = %.4f%n", llaves[2]));

        lblX.setText(String.format("%.4f", llaves[0]));
        lblY.setText(String.format("%.4f", llaves[1]));
        lblZ.setText(String.format("%.4f", llaves[2]));

        double[] W = {0.5, 0.3, 0.2};
        double hash = Seguridad.productoPunto(llaves, W);
        double cHash = 10 * hash;
        double cKdotW = Seguridad.productoPunto(new double[]{10*llaves[0], 10*llaves[1], 10*llaves[2]}, W);

        sb.append("\n--- Validacion de Integridad (Producto Punto)\n");
        sb.append(String.format("  W = [0.5, 0.3, 0.2]%n"));
        sb.append(String.format("  K . W = (%.4f)(0.5) + (%.4f)(0.3) + (%.4f)(0.2)%n", llaves[0], llaves[1], llaves[2]));
        sb.append(String.format("        = %.4f%n", hash));
        sb.append("  Integridad confirmada. Acceso autorizado.\n");

        sb.append("\n--- Propiedad de Homogeneidad (c=10) -------\n");
        sb.append(String.format("  c * (K.W)  = 10 * %.4f = %.4f%n", hash, cHash));
        sb.append(String.format("  (cK) . W   = %.4f%n", cKdotW));
        sb.append("  Propiedad verificada.\n");
        sb.append("\n============================================\n");

        lblPunto.setText(String.format("%.4f", hash));
        lblHomo.setText(String.format("10 x %.4f = %.4f", hash, cHash));

        areaResultados.setText(sb.toString());
        areaResultados.setCaretPosition(0);

        // Mostrar pestaña Resumen al terminar
        tabs.setSelectedIndex(0);
    }

    private void limpiar() {
        for (int i = 0; i < 3; i++) for (int j = 0; j < 4; j++) campos[i][j].setText("0");
        areaResultados.setText("Ingresa los coeficientes y presiona\n\"Calcular llaves\" para ver el detalle completo.");
        for (int i = 0; i < 3; i++) for (int j = 0; j < 5; j++) modeloTabla.setValueAt("", i, j);
        lblDet.setText("---"); lblX.setText("---"); lblY.setText("---");
        lblZ.setText("---"); lblPunto.setText("---"); lblHomo.setText("---");
    }

    // ===== HELPERS =====
    private JLabel resultRow(String key, String val) {
        JLabel l = new JLabel(val);
        l.setFont(new Font("Consolas", Font.BOLD, 15));
        l.setForeground(new Color(18, 83, 150));
        return l;
    }

    private JPanel filaResultado(String etiqueta, JLabel valorLabel, Color bg) {
        JPanel p = new JPanel(new BorderLayout(10, 0));
        p.setBackground(bg);
        p.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(210, 220, 238), 1, true),
            new EmptyBorder(7, 12, 7, 12)));
        JLabel key = new JLabel(etiqueta);
        key.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        key.setForeground(new Color(60, 80, 110));
        p.add(key, BorderLayout.WEST);
        p.add(valorLabel, BorderLayout.EAST);
        return p;
    }

    private JPanel card(String titulo) {
        JPanel p = new JPanel(new BorderLayout(0, 5));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(205, 218, 238), 1, true),
            new EmptyBorder(9, 11, 9, 11)));
        JLabel l = new JLabel(titulo);
        l.setFont(new Font("Segoe UI", Font.BOLD, 11));
        l.setForeground(new Color(18, 83, 150));
        l.setBorder(new EmptyBorder(0, 0, 3, 0));
        p.add(l, BorderLayout.NORTH);
        return p;
    }

    private JLabel secLabel(String t) {
        JLabel l = new JLabel(t.toUpperCase());
        l.setFont(new Font("Segoe UI", Font.BOLD, 11));
        l.setForeground(new Color(100, 115, 140));
        l.setBorder(new EmptyBorder(0, 0, 3, 0));
        return l;
    }

    private JButton boton(String texto, Color bg, Color fg) {
        JButton b = new JButton(texto);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setBackground(bg);
        b.setForeground(fg);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(10, 14, 10, 14));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }
}
