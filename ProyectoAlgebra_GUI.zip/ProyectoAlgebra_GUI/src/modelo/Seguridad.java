package modelo;

public class Seguridad {

    public static double determinante(double[][] A) {
        double pos = A[0][0]*A[1][1]*A[2][2] + A[0][1]*A[1][2]*A[2][0] + A[0][2]*A[1][0]*A[2][1];
        double neg = A[2][0]*A[1][1]*A[0][2] + A[2][1]*A[1][2]*A[0][0] + A[2][2]*A[1][0]*A[0][1];
        return pos - neg;
    }

    public static double[] gaussJordan(double[][] A, double[] b) {
        double[][] M = new double[3][4];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) M[i][j] = A[i][j];
            M[i][3] = b[i];
        }
        for (int col = 0; col < 3; col++) {
            double piv = M[col][col];
            for (int j = 0; j < 4; j++) M[col][j] /= piv;
            for (int fila = 0; fila < 3; fila++) {
                if (fila == col) continue;
                double factor = M[fila][col];
                for (int j = 0; j < 4; j++) M[fila][j] -= factor * M[col][j];
            }
        }
        return new double[]{M[0][3], M[1][3], M[2][3]};
    }

    public static double productoPunto(double[] u, double[] v) {
        return u[0]*v[0] + u[1]*v[1] + u[2]*v[2];
    }
}
